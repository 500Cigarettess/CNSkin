player_manager.AddValidModel( "14th Doctor", "models/doctorwho/14thdoctor/14thdoctor.mdl" )
list.Set( "PlayerOptionsModel",  "14th Doctor", "models/doctorwho/14thdoctor/14thdoctor.mdl" )
