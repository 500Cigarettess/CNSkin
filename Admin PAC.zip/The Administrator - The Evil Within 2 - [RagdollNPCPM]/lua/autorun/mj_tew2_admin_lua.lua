player_manager.AddValidModel( "The Administrator", 				"models/players/mj_tew2_admin.mdl" )
list.Set( "PlayerOptionsModel",  "The Administrator",				"models/players/mj_tew2_admin.mdl" )
player_manager.AddValidHands(	"The Administrator", "models/players/tew2_admin_c_arms.mdl", 0, "00000000" )

local Category = "The Evil Within 2"

local NPC =
{
	Name = "The Administrator - Friendly",
	Class = "npc_citizen",
	Health = "100",
	KeyValues = { citizentype = 4 },
	Model = "models/players/mj_tew2_admin.mdl",
	Category = Category
}

list.Set( "NPC", "tew2_admin_ally", NPC )

